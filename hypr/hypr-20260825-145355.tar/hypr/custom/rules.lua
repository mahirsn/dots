local hideFromScreeshareClasses = { "proton-pass", "Termius", "obsidian" }

hl.on("window.open", function(win)
  if win == nil then return end
  for _, c in ipairs(hideFromScreeshareClasses) do
    if win.class == c then
      hl.dispatch(hl.dsp.window.tag({ tag = "+noscreenshare", window = win }))
      break
    end
  end
end)

-- "noscreenshare" tag
-- tag is required because I want to control the windows'
-- screenshare state with a keybind
hl.window_rule({
  match = { tag = "noscreenshare" },
  no_screen_share = true,
})

hl.window_rule({
  match = { tag = "noscreenshare" },
  border_color = "rgb(ff0000)",
  border_size = 4,
})
