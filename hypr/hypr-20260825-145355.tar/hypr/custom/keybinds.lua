-- ============================================================
-- PERSONAL KEYBINDS (overrides)
-- Loaded AFTER hyprland/keybinds.lua, so your binds win.
-- Base file is pulled from end-4 upstream:
--   https://raw.githubusercontent.com/end-4/dots-hyprland/main/dots/.config/hypr/hyprland/keybinds.lua
-- Keep ALL personal changes HERE so re-pulling upstream never
-- overwrites them.
-- ============================================================

-- Edit this file quickly
hl.bind("CTRL+SUPER+ALT+Slash", hl.dsp.exec_cmd("xdg-open ~/.config/hypr/custom/keybinds.lua"), {description = "Edit user keybinds"} )

-- Eski custom/keybindings.lua'da kalan örnekler (hiç yüklenmiyordu):
--   SUPER+T zaten terminal açıyor (base: foot -> kitty -> ... sıralı).
--   Sadece kitty istersen şu iki satırı aç:
-- hl.unbind("SUPER", "T")
-- hl.bind("SUPER + T", hl.dsp.exec_cmd("kitty -1"), { description = "App: Terminal" })

--   SUPER+ENTER ile terminal açmak istersen:
-- hl.bind("SUPER + ENTER", hl.dsp.exec_cmd("kitty -1"), { description = "App: Terminal" })

-- ============================================================
-- WORKSPACE extras (eski dots'tan — raw'da yok, kaybolmasın)
-- ============================================================

-- SUPER+SHIFT+sayı: pencereyi workspace'e taşı ve takip et
for i = 1, 10 do
    hl.bind("SUPER + SHIFT + " .. (i % 10), function()
        hl.dispatch(hl.dsp.window.move({ workspace = workspace_in_group(i), follow = true }))
    end, { description = "Window: Send to workspace " .. i .. " and follow" })
end

-- SUPER+SHIFT+": pencereyi scratchpad'e taşı ve takip et
hl.bind("SUPER + SHIFT + QUOTEDBL", function()
    hl.dispatch(hl.dsp.window.move({ workspace = "special:special", follow = true }))
end, { description = "Window: Send to scratchpad and follow" })

hl.bind("SUPER + QUOTEDBL", hl.dsp.workspace.toggle_special("special"), { description = "Workspace: Toggle scratchpad" })

hl.unbind("SUPER + S", hl.dsp.workspace.toggle_special("special"), { description = "Workspace: Toggle scratchpad" })


hl.bind("SUPER + SHIFT + H", hl.dsp.window.tag({ tag = "noscreenshare" }))

hl.bind("SUPER + SPACE", hl.dsp.global("quickshell:searchToggleRelease"), { description = "Shell: Toggle search" })


hl.unbind("SUPER + C", hl.dsp.exec_cmd(codeEditor), { description = "App: Code editor" })
hl.unbind("CTRL + SUPER + SHIFT + ALT + W", hl.dsp.exec_cmd(officeSoftware), { description = "App: Office software" })
hl.unbind("SUPER + X", hl.dsp.exec_cmd(textEditor), { description = "App: Text editor" })
hl.unbind("CTRL + SUPER + V", hl.dsp.exec_cmd(volumeMixer), { description = "App: Volume mixer" })
hl.unbind("SUPER + I", hl.dsp.exec_cmd(settingsApp), { description = "App: Settings app" })
hl.unbind("SUPER + W", hl.dsp.exec_cmd(browser), { description = "App: Browser" })
hl.unbind("SUPER + T", hl.dsp.exec_cmd(terminal))
hl.unbind("CTRL + ALT + T", hl.dsp.exec_cmd(terminal))
