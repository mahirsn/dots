hl.monitor({ output = "eDP-2", mode = "2560x1600@165.00Hz", position = "0x0", scale = 1 })
hl.monitor({ output = "HDMI-A-1", mode = "1920x1080@60.00Hz", position = "-1920x0", scale = 1 })
