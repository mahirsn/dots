hl.config({
    general = {
        col = {
            active_border   = "rgba(46474577)",
            inactive_border = "rgba(1b1c1a33)",
        },
    },
    misc = {
        background_color = "rgba(131412FF)",
    },
})

hl.window_rule({
    match        = { pin = 1 },
    border_color = "rgba(bccabbAA) rgba(bccabb77)",
})
